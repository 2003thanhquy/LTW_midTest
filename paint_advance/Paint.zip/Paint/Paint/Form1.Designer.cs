﻿using System.Reflection;

namespace Paint
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cMSDStyle = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.cMSBrush = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnZoomout = new System.Windows.Forms.Button();
            this.btnZoomin = new System.Windows.Forms.Button();
            this.btnEraser = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnPen = new System.Windows.Forms.Button();
            this.btnFill = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnLine = new System.Windows.Forms.Button();
            this.btnRectangle = new System.Windows.Forms.Button();
            this.btnEllipse = new System.Windows.Forms.Button();
            this.btnTriangle = new System.Windows.Forms.Button();
            this.btnRhombus = new System.Windows.Forms.Button();
            this.btnPentagon = new System.Windows.Forms.Button();
            this.btnHexagon = new System.Windows.Forms.Button();
            this.btnArc = new System.Windows.Forms.Button();
            this.btnPolygon = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnOpenColor = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnGroup = new System.Windows.Forms.Button();
            this.btnUngroup = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlPen = new System.Windows.Forms.Panel();
            this.btnBrushStyle = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPenDStyle = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.ptbColor = new System.Windows.Forms.PictureBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cMSDStyle.SuspendLayout();
            this.cMSBrush.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.pnlPen.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbColor)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cMSDStyle
            // 
            this.cMSDStyle.AutoSize = false;
            this.cMSDStyle.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cMSDStyle.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6});
            this.cMSDStyle.Name = "contextMenuStrip1";
            this.cMSDStyle.Size = new System.Drawing.Size(250, 185);
            this.cMSDStyle.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.cMSDStyle_ItemClicked);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.AutoSize = false;
            this.toolStripMenuItem1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.BackgroundImage")));
            this.toolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(250, 30);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.AutoSize = false;
            this.toolStripMenuItem2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem2.BackgroundImage")));
            this.toolStripMenuItem2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(250, 30);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.AutoSize = false;
            this.toolStripMenuItem3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem3.BackgroundImage")));
            this.toolStripMenuItem3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(250, 30);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.AutoSize = false;
            this.toolStripMenuItem4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem4.BackgroundImage")));
            this.toolStripMenuItem4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(250, 30);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.AutoSize = false;
            this.toolStripMenuItem5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem5.BackgroundImage")));
            this.toolStripMenuItem5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(250, 30);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.AutoSize = false;
            this.toolStripMenuItem6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem6.BackgroundImage")));
            this.toolStripMenuItem6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(250, 30);
            // 
            // cMSBrush
            // 
            this.cMSBrush.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cMSBrush.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10,
            this.toolStripMenuItem11});
            this.cMSBrush.Name = "contextMenuStrip2";
            this.cMSBrush.Size = new System.Drawing.Size(212, 124);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(211, 24);
            this.toolStripMenuItem7.Text = "SolidBrush";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(211, 24);
            this.toolStripMenuItem8.Text = "HatchBrush";
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(211, 24);
            this.toolStripMenuItem9.Text = "LinearGradientBrush";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(211, 24);
            this.toolStripMenuItem10.Text = "PathGradientBrush";
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(211, 24);
            this.toolStripMenuItem11.Text = "TextureBrush";
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 50;
            // 
            // btnZoomout
            // 
            this.btnZoomout.BackgroundImage = global::Paint.Properties.Resources.zoomout_ss;
            this.btnZoomout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnZoomout.Location = new System.Drawing.Point(276, 65);
            this.btnZoomout.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnZoomout.Name = "btnZoomout";
            this.btnZoomout.Size = new System.Drawing.Size(60, 61);
            this.btnZoomout.TabIndex = 5;
            this.btnZoomout.Text = "\r\n";
            this.toolTip1.SetToolTip(this.btnZoomout, "zoomOut");
            this.btnZoomout.UseVisualStyleBackColor = true;
            this.btnZoomout.Click += new System.EventHandler(this.btnZoomout_Click);
            // 
            // btnZoomin
            // 
            this.btnZoomin.BackgroundImage = global::Paint.Properties.Resources.zoomin1;
            this.btnZoomin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnZoomin.Location = new System.Drawing.Point(276, 6);
            this.btnZoomin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnZoomin.Name = "btnZoomin";
            this.btnZoomin.Size = new System.Drawing.Size(60, 57);
            this.btnZoomin.TabIndex = 4;
            this.btnZoomin.Text = "\r\n";
            this.toolTip1.SetToolTip(this.btnZoomin, "zoomIn");
            this.btnZoomin.UseVisualStyleBackColor = true;
            this.btnZoomin.Click += new System.EventHandler(this.btnZoomin_Click);
            // 
            // btnEraser
            // 
            this.btnEraser.BackgroundImage = global::Paint.Properties.Resources.ic_eraser;
            this.btnEraser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnEraser.Location = new System.Drawing.Point(144, 65);
            this.btnEraser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnEraser.Name = "btnEraser";
            this.btnEraser.Size = new System.Drawing.Size(60, 61);
            this.btnEraser.TabIndex = 3;
            this.btnEraser.Text = "\r\n";
            this.toolTip1.SetToolTip(this.btnEraser, "eraser");
            this.btnEraser.UseVisualStyleBackColor = true;
            this.btnEraser.Click += new System.EventHandler(this.btnEraser_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImage = global::Paint.Properties.Resources.trash;
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDelete.Location = new System.Drawing.Point(3, 65);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(67, 61);
            this.btnDelete.TabIndex = 3;
            this.toolTip1.SetToolTip(this.btnDelete, "Delete");
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImage = global::Paint.Properties.Resources.ic_clear;
            this.btnClear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnClear.Location = new System.Drawing.Point(78, 65);
            this.btnClear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(60, 61);
            this.btnClear.TabIndex = 2;
            this.btnClear.Text = "\r\n";
            this.toolTip1.SetToolTip(this.btnClear, "Clean");
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnPen
            // 
            this.btnPen.BackgroundImage = global::Paint.Properties.Resources.ic_pen;
            this.btnPen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPen.Location = new System.Drawing.Point(144, 4);
            this.btnPen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPen.Name = "btnPen";
            this.btnPen.Size = new System.Drawing.Size(60, 58);
            this.btnPen.TabIndex = 0;
            this.btnPen.Text = "\r\n";
            this.toolTip1.SetToolTip(this.btnPen, "Pen");
            this.btnPen.UseVisualStyleBackColor = true;
            this.btnPen.Click += new System.EventHandler(this.btnPen_Click);
            // 
            // btnFill
            // 
            this.btnFill.BackgroundImage = global::Paint.Properties.Resources.ic_fill;
            this.btnFill.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnFill.Location = new System.Drawing.Point(210, 6);
            this.btnFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnFill.Name = "btnFill";
            this.btnFill.Size = new System.Drawing.Size(60, 57);
            this.btnFill.TabIndex = 1;
            this.btnFill.Text = "\r\n";
            this.toolTip1.SetToolTip(this.btnFill, "Fill");
            this.btnFill.UseVisualStyleBackColor = true;
            this.btnFill.Click += new System.EventHandler(this.btnFill_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::Paint.Properties.Resources.brush;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(103, 38);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(55, 50);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox2, "Dash Styles");
            // 
            // btnLine
            // 
            this.btnLine.BackgroundImage = global::Paint.Properties.Resources.line_s;
            this.btnLine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLine.Location = new System.Drawing.Point(3, 2);
            this.btnLine.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLine.Name = "btnLine";
            this.btnLine.Size = new System.Drawing.Size(64, 58);
            this.btnLine.TabIndex = 0;
            this.toolTip1.SetToolTip(this.btnLine, "Line");
            this.btnLine.UseVisualStyleBackColor = true;
            this.btnLine.Click += new System.EventHandler(this.btnLine_Click);
            // 
            // btnRectangle
            // 
            this.btnRectangle.BackgroundImage = global::Paint.Properties.Resources.rectangle;
            this.btnRectangle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRectangle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRectangle.Location = new System.Drawing.Point(73, 2);
            this.btnRectangle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRectangle.Name = "btnRectangle";
            this.btnRectangle.Size = new System.Drawing.Size(64, 58);
            this.btnRectangle.TabIndex = 1;
            this.toolTip1.SetToolTip(this.btnRectangle, "Rectangle");
            this.btnRectangle.UseVisualStyleBackColor = true;
            this.btnRectangle.Click += new System.EventHandler(this.btnRectangle_Click);
            // 
            // btnEllipse
            // 
            this.btnEllipse.BackgroundImage = global::Paint.Properties.Resources.ellipse_n;
            this.btnEllipse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnEllipse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEllipse.Location = new System.Drawing.Point(143, 2);
            this.btnEllipse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnEllipse.Name = "btnEllipse";
            this.btnEllipse.Size = new System.Drawing.Size(64, 58);
            this.btnEllipse.TabIndex = 3;
            this.toolTip1.SetToolTip(this.btnEllipse, "Ellipse");
            this.btnEllipse.UseVisualStyleBackColor = true;
            this.btnEllipse.Click += new System.EventHandler(this.btnEllipse_Click);
            // 
            // btnTriangle
            // 
            this.btnTriangle.BackgroundImage = global::Paint.Properties.Resources.triangle_n;
            this.btnTriangle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnTriangle.Location = new System.Drawing.Point(213, 2);
            this.btnTriangle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTriangle.Name = "btnTriangle";
            this.btnTriangle.Size = new System.Drawing.Size(64, 54);
            this.btnTriangle.TabIndex = 5;
            this.toolTip1.SetToolTip(this.btnTriangle, "Triangle");
            this.btnTriangle.UseVisualStyleBackColor = true;
            this.btnTriangle.Click += new System.EventHandler(this.btnTriangle_Click);
            // 
            // btnRhombus
            // 
            this.btnRhombus.BackgroundImage = global::Paint.Properties.Resources.diamon_n;
            this.btnRhombus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRhombus.Location = new System.Drawing.Point(3, 64);
            this.btnRhombus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRhombus.Name = "btnRhombus";
            this.btnRhombus.Size = new System.Drawing.Size(64, 54);
            this.btnRhombus.TabIndex = 6;
            this.toolTip1.SetToolTip(this.btnRhombus, "Rhombus");
            this.btnRhombus.UseVisualStyleBackColor = true;
            this.btnRhombus.Click += new System.EventHandler(this.btnRhombus_Click);
            // 
            // btnPentagon
            // 
            this.btnPentagon.BackgroundImage = global::Paint.Properties.Resources.pentagon_n;
            this.btnPentagon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPentagon.Location = new System.Drawing.Point(73, 64);
            this.btnPentagon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPentagon.Name = "btnPentagon";
            this.btnPentagon.Size = new System.Drawing.Size(64, 54);
            this.btnPentagon.TabIndex = 7;
            this.toolTip1.SetToolTip(this.btnPentagon, "Pentagon");
            this.btnPentagon.UseVisualStyleBackColor = true;
            this.btnPentagon.Click += new System.EventHandler(this.btnPentagon_Click);
            // 
            // btnHexagon
            // 
            this.btnHexagon.BackgroundImage = global::Paint.Properties.Resources.hexagon_n;
            this.btnHexagon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnHexagon.Location = new System.Drawing.Point(143, 64);
            this.btnHexagon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnHexagon.Name = "btnHexagon";
            this.btnHexagon.Size = new System.Drawing.Size(64, 54);
            this.btnHexagon.TabIndex = 8;
            this.toolTip1.SetToolTip(this.btnHexagon, "Hexagon");
            this.btnHexagon.UseVisualStyleBackColor = true;
            this.btnHexagon.Click += new System.EventHandler(this.btnHexagon_Click);
            // 
            // btnArc
            // 
            this.btnArc.BackgroundImage = global::Paint.Properties.Resources.arc_n;
            this.btnArc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnArc.Location = new System.Drawing.Point(213, 64);
            this.btnArc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnArc.Name = "btnArc";
            this.btnArc.Size = new System.Drawing.Size(64, 54);
            this.btnArc.TabIndex = 9;
            this.toolTip1.SetToolTip(this.btnArc, "Arc");
            this.btnArc.UseVisualStyleBackColor = true;
            this.btnArc.Click += new System.EventHandler(this.btnArc_Click);
            // 
            // btnPolygon
            // 
            this.btnPolygon.BackgroundImage = global::Paint.Properties.Resources.polygon;
            this.btnPolygon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPolygon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPolygon.Location = new System.Drawing.Point(3, 125);
            this.btnPolygon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPolygon.Name = "btnPolygon";
            this.btnPolygon.Size = new System.Drawing.Size(64, 59);
            this.btnPolygon.TabIndex = 10;
            this.toolTip1.SetToolTip(this.btnPolygon, "Polygon");
            this.btnPolygon.UseVisualStyleBackColor = true;
            this.btnPolygon.Click += new System.EventHandler(this.btnPolygon_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(164, 38);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 50);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, "Brush");
            // 
            // btnOpenColor
            // 
            this.btnOpenColor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOpenColor.BackgroundImage")));
            this.btnOpenColor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnOpenColor.Location = new System.Drawing.Point(425, 27);
            this.btnOpenColor.Name = "btnOpenColor";
            this.btnOpenColor.Size = new System.Drawing.Size(90, 76);
            this.btnOpenColor.TabIndex = 50;
            this.toolTip1.SetToolTip(this.btnOpenColor, "More Colors");
            this.btnOpenColor.UseVisualStyleBackColor = true;
            this.btnOpenColor.Click += new System.EventHandler(this.btnOpenColor_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.BackgroundImage = global::Paint.Properties.Resources.ic_select;
            this.btnSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSelect.Location = new System.Drawing.Point(210, 66);
            this.btnSelect.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(60, 61);
            this.btnSelect.TabIndex = 0;
            this.toolTip1.SetToolTip(this.btnSelect, "Select");
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnGroup
            // 
            this.btnGroup.BackgroundImage = global::Paint.Properties.Resources.ic_group;
            this.btnGroup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnGroup.Location = new System.Drawing.Point(3, 3);
            this.btnGroup.Name = "btnGroup";
            this.btnGroup.Size = new System.Drawing.Size(67, 59);
            this.btnGroup.TabIndex = 1;
            this.toolTip1.SetToolTip(this.btnGroup, "Group");
            this.btnGroup.UseVisualStyleBackColor = true;
            this.btnGroup.Click += new System.EventHandler(this.btnGroup_Click);
            // 
            // btnUngroup
            // 
            this.btnUngroup.BackgroundImage = global::Paint.Properties.Resources.ungroup_objects;
            this.btnUngroup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnUngroup.Location = new System.Drawing.Point(76, 3);
            this.btnUngroup.Name = "btnUngroup";
            this.btnUngroup.Size = new System.Drawing.Size(62, 58);
            this.btnUngroup.TabIndex = 2;
            this.toolTip1.SetToolTip(this.btnUngroup, "UnGroup");
            this.btnUngroup.UseVisualStyleBackColor = true;
            this.btnUngroup.Click += new System.EventHandler(this.btnUngroup_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.AutoScroll = true;
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlMain.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Margin = new System.Windows.Forms.Padding(0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1530, 618);
            this.pnlMain.TabIndex = 7;
            this.pnlMain.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMain_Paint);
            this.pnlMain.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pnlMain_MouseClick);
            this.pnlMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlMain_MouseDown);
            this.pnlMain.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlMain_MouseMove);
            this.pnlMain.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlMain_MouseUp);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(3, 5);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(315, 128);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.btnLine, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnRectangle, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnEllipse, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnTriangle, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnRhombus, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnPentagon, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnHexagon, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnArc, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnPolygon, 0, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(8, 5);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.22222F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.73913F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.70531F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(280, 281);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pnlPen
            // 
            this.pnlPen.BackColor = System.Drawing.SystemColors.Control;
            this.pnlPen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPen.Controls.Add(this.pictureBox1);
            this.pnlPen.Controls.Add(this.btnBrushStyle);
            this.pnlPen.Controls.Add(this.groupBox1);
            this.pnlPen.Controls.Add(this.pictureBox2);
            this.pnlPen.Controls.Add(this.label3);
            this.pnlPen.Controls.Add(this.btnPenDStyle);
            this.pnlPen.Location = new System.Drawing.Point(676, 3);
            this.pnlPen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlPen.Name = "pnlPen";
            this.pnlPen.Size = new System.Drawing.Size(234, 133);
            this.pnlPen.TabIndex = 3;
            // 
            // btnBrushStyle
            // 
            this.btnBrushStyle.Image = global::Paint.Properties.Resources.arrow_down;
            this.btnBrushStyle.Location = new System.Drawing.Point(164, 93);
            this.btnBrushStyle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBrushStyle.Name = "btnBrushStyle";
            this.btnBrushStyle.Size = new System.Drawing.Size(63, 23);
            this.btnBrushStyle.TabIndex = 1;
            this.btnBrushStyle.UseVisualStyleBackColor = true;
            this.btnBrushStyle.Click += new System.EventHandler(this.btnBrushStyle_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtWidth);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 28);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(94, 76);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Width";
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(16, 31);
            this.txtWidth.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtWidth.Multiline = true;
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(57, 27);
            this.txtWidth.TabIndex = 6;
            this.txtWidth.Text = "5";
            this.txtWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::Paint.Properties.Resources.arrow_down;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.Location = new System.Drawing.Point(70, 41);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(21, 23);
            this.button2.TabIndex = 5;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Paint.Properties.Resources.arrow_up;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Location = new System.Drawing.Point(70, 24);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(21, 23);
            this.button1.TabIndex = 4;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(91, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "PEN";
            // 
            // btnPenDStyle
            // 
            this.btnPenDStyle.Image = global::Paint.Properties.Resources.arrow_down;
            this.btnPenDStyle.Location = new System.Drawing.Point(102, 92);
            this.btnPenDStyle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPenDStyle.Name = "btnPenDStyle";
            this.btnPenDStyle.Size = new System.Drawing.Size(56, 23);
            this.btnPenDStyle.TabIndex = 5;
            this.btnPenDStyle.UseVisualStyleBackColor = true;
            this.btnPenDStyle.Click += new System.EventHandler(this.btnPenDStyle_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.pictureBox21);
            this.panel6.Controls.Add(this.btnOpenColor);
            this.panel6.Controls.Add(this.pictureBox22);
            this.panel6.Controls.Add(this.pictureBox23);
            this.panel6.Controls.Add(this.pictureBox24);
            this.panel6.Controls.Add(this.pictureBox25);
            this.panel6.Controls.Add(this.pictureBox26);
            this.panel6.Controls.Add(this.pictureBox27);
            this.panel6.Controls.Add(this.pictureBox28);
            this.panel6.Controls.Add(this.pictureBox29);
            this.panel6.Controls.Add(this.pictureBox30);
            this.panel6.Controls.Add(this.pictureBox11);
            this.panel6.Controls.Add(this.pictureBox12);
            this.panel6.Controls.Add(this.pictureBox13);
            this.panel6.Controls.Add(this.pictureBox14);
            this.panel6.Controls.Add(this.pictureBox15);
            this.panel6.Controls.Add(this.pictureBox16);
            this.panel6.Controls.Add(this.pictureBox17);
            this.panel6.Controls.Add(this.pictureBox18);
            this.panel6.Controls.Add(this.pictureBox19);
            this.panel6.Controls.Add(this.pictureBox20);
            this.panel6.Controls.Add(this.pictureBox7);
            this.panel6.Controls.Add(this.pictureBox8);
            this.panel6.Controls.Add(this.pictureBox9);
            this.panel6.Controls.Add(this.pictureBox10);
            this.panel6.Controls.Add(this.pictureBox4);
            this.panel6.Controls.Add(this.pictureBox5);
            this.panel6.Controls.Add(this.pictureBox6);
            this.panel6.Controls.Add(this.pictureBox3);
            this.panel6.Controls.Add(this.pictureBox31);
            this.panel6.Controls.Add(this.pictureBox32);
            this.panel6.Location = new System.Drawing.Point(1003, 4);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(545, 129);
            this.panel6.TabIndex = 18;
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox21.Location = new System.Drawing.Point(376, 92);
            this.pictureBox21.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(33, 31);
            this.pictureBox21.TabIndex = 47;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox22.Location = new System.Drawing.Point(335, 91);
            this.pictureBox22.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(33, 31);
            this.pictureBox22.TabIndex = 46;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox23.Location = new System.Drawing.Point(293, 92);
            this.pictureBox23.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(33, 31);
            this.pictureBox23.TabIndex = 45;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox24.Location = new System.Drawing.Point(252, 91);
            this.pictureBox24.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(33, 31);
            this.pictureBox24.TabIndex = 44;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox25.Location = new System.Drawing.Point(210, 91);
            this.pictureBox25.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(33, 31);
            this.pictureBox25.TabIndex = 43;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox26
            // 
            this.pictureBox26.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox26.Location = new System.Drawing.Point(169, 92);
            this.pictureBox26.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(33, 31);
            this.pictureBox26.TabIndex = 42;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox27
            // 
            this.pictureBox27.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox27.Location = new System.Drawing.Point(128, 93);
            this.pictureBox27.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(33, 31);
            this.pictureBox27.TabIndex = 41;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox28
            // 
            this.pictureBox28.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox28.Location = new System.Drawing.Point(86, 91);
            this.pictureBox28.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(33, 31);
            this.pictureBox28.TabIndex = 40;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox29
            // 
            this.pictureBox29.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox29.Location = new System.Drawing.Point(45, 91);
            this.pictureBox29.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(33, 31);
            this.pictureBox29.TabIndex = 39;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox30
            // 
            this.pictureBox30.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox30.Location = new System.Drawing.Point(4, 91);
            this.pictureBox30.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(33, 31);
            this.pictureBox30.TabIndex = 38;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.MediumOrchid;
            this.pictureBox11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox11.Location = new System.Drawing.Point(376, 54);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(33, 31);
            this.pictureBox11.TabIndex = 37;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.SteelBlue;
            this.pictureBox12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox12.Location = new System.Drawing.Point(335, 54);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(33, 31);
            this.pictureBox12.TabIndex = 36;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.pictureBox13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox13.Location = new System.Drawing.Point(293, 54);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(33, 31);
            this.pictureBox13.TabIndex = 35;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.Lime;
            this.pictureBox14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox14.Location = new System.Drawing.Point(252, 53);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(33, 31);
            this.pictureBox14.TabIndex = 34;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.SandyBrown;
            this.pictureBox15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox15.Location = new System.Drawing.Point(211, 53);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(33, 31);
            this.pictureBox15.TabIndex = 33;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.Tomato;
            this.pictureBox16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox16.Location = new System.Drawing.Point(169, 53);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(33, 31);
            this.pictureBox16.TabIndex = 32;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.pictureBox17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox17.Location = new System.Drawing.Point(128, 53);
            this.pictureBox17.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(33, 31);
            this.pictureBox17.TabIndex = 31;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.RosyBrown;
            this.pictureBox18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox18.Location = new System.Drawing.Point(87, 53);
            this.pictureBox18.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(33, 31);
            this.pictureBox18.TabIndex = 30;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.Silver;
            this.pictureBox19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox19.Location = new System.Drawing.Point(45, 54);
            this.pictureBox19.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(33, 31);
            this.pictureBox19.TabIndex = 29;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.White;
            this.pictureBox20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox20.Location = new System.Drawing.Point(4, 52);
            this.pictureBox20.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(33, 31);
            this.pictureBox20.TabIndex = 28;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox7.Location = new System.Drawing.Point(376, 7);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(33, 31);
            this.pictureBox7.TabIndex = 27;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.pictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox8.Location = new System.Drawing.Point(335, 7);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(33, 31);
            this.pictureBox8.TabIndex = 26;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.pictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox9.Location = new System.Drawing.Point(294, 7);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(33, 31);
            this.pictureBox9.TabIndex = 25;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.Green;
            this.pictureBox10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox10.Location = new System.Drawing.Point(252, 7);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(33, 31);
            this.pictureBox10.TabIndex = 24;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Yellow;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox4.Location = new System.Drawing.Point(211, 7);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(33, 31);
            this.pictureBox4.TabIndex = 23;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox5.Location = new System.Drawing.Point(169, 7);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(33, 31);
            this.pictureBox5.TabIndex = 22;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox6.Location = new System.Drawing.Point(128, 7);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(33, 31);
            this.pictureBox6.TabIndex = 21;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox3.Location = new System.Drawing.Point(87, 7);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 31);
            this.pictureBox3.TabIndex = 20;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox31
            // 
            this.pictureBox31.BackColor = System.Drawing.Color.Gray;
            this.pictureBox31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox31.Location = new System.Drawing.Point(45, 7);
            this.pictureBox31.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(33, 31);
            this.pictureBox31.TabIndex = 19;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Click += new System.EventHandler(this.color_Click);
            // 
            // pictureBox32
            // 
            this.pictureBox32.BackColor = System.Drawing.Color.Black;
            this.pictureBox32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox32.Location = new System.Drawing.Point(4, 7);
            this.pictureBox32.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(33, 31);
            this.pictureBox32.TabIndex = 18;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Click += new System.EventHandler(this.color_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.ptbColor);
            this.panel5.Controls.Add(this.pnlPen);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1581, 138);
            this.panel5.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(946, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 16);
            this.label1.TabIndex = 51;
            this.label1.Text = "Color";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Control;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.btnSelect);
            this.panel7.Controls.Add(this.btnClear);
            this.panel7.Controls.Add(this.btnZoomout);
            this.panel7.Controls.Add(this.btnZoomin);
            this.panel7.Controls.Add(this.btnEraser);
            this.panel7.Controls.Add(this.btnDelete);
            this.panel7.Controls.Add(this.btnPen);
            this.panel7.Controls.Add(this.btnFill);
            this.panel7.Controls.Add(this.btnGroup);
            this.panel7.Controls.Add(this.btnUngroup);
            this.panel7.Location = new System.Drawing.Point(324, 4);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(346, 130);
            this.panel7.TabIndex = 49;
            // 
            // ptbColor
            // 
            this.ptbColor.BackColor = System.Drawing.Color.Black;
            this.ptbColor.Location = new System.Drawing.Point(935, 38);
            this.ptbColor.Margin = new System.Windows.Forms.Padding(4);
            this.ptbColor.Name = "ptbColor";
            this.ptbColor.Size = new System.Drawing.Size(60, 55);
            this.ptbColor.TabIndex = 48;
            this.ptbColor.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.pnlMain);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 135);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1581, 622);
            this.panel2.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1581, 757);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.cMSDStyle.ResumeLayout(false);
            this.cMSBrush.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.pnlPen.ResumeLayout(false);
            this.pnlPen.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ptbColor)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip cMSDStyle;
        private System.Windows.Forms.ContextMenuStrip cMSBrush;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.Button btnEraser;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnFill;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btnPen;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Button btnUngroup;
        private System.Windows.Forms.Button btnGroup;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnBrushStyle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnLine;
        private System.Windows.Forms.Button btnRectangle;
        private System.Windows.Forms.Button btnEllipse;
        private System.Windows.Forms.Button btnTriangle;
        private System.Windows.Forms.Button btnRhombus;
        private System.Windows.Forms.Button btnPentagon;
        private System.Windows.Forms.Button btnHexagon;
        private System.Windows.Forms.Button btnArc;
        private System.Windows.Forms.Button btnPolygon;
        private System.Windows.Forms.Panel pnlPen;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnPenDStyle;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox ptbColor;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnOpenColor;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnZoomout;
        private System.Windows.Forms.Button btnZoomin;
        private System.Windows.Forms.Panel panel2;
    }
}

